---------------------------------------------------------------

                              Data

---------------------------------------------------------------

[super@enyo ics432_pa5_adam359]$ ./run_seq oil3 photos
rpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpw
Time spent reading: 4.385 sec.
Time spent processing: 377.692 sec.
Time spent writing: 9.019 sec.
Overall execution time: 391.191 sec.
[super@enyo ics432_pa5_adam359]$ ./run_concur oil3 photos
rrrrrrrrrprwprwpwrprwprwpwrprwprwprwprwprwprwprwprwprwprwpprwrwprwprwprwprwprwprwprwprwprwprwprwprwpwrprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprpwwrprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwpwpwpwpwpwpwpwpwpw
Time spent reading: 6.395 sec.
Time spent processing: 383.504 sec.
Time spent writing: 19.041 sec.
Overall execution time: 384.028 sec.

[super@enyo ics432_pa5_adam359]$ ./run_seq oil1 photos
rpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpw
Time spent reading: 4.322 sec.
Time spent processing: 263.156 sec.
Time spent writing: 8.974 sec.
Overall execution time: 276.562 sec.
[super@enyo ics432_pa5_adam359]$ ./run_concur oil1 photos
rrrrrrrrrprwprwpwrprwprwpwrprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwpwrprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwpwrprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwpwpwpwpwpwpwpwpwpw
Time spent reading: 4.808 sec.
Time spent processing: 260.677 sec.
Time spent writing: 12.491 sec.
Overall execution time: 261.152 sec.

[super@enyo ics432_pa5_adam359]$ ./run_seq smear photos
rpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpw
Time spent reading: 4.335 sec.
Time spent processing: 29.642 sec.
Time spent writing: 9.249 sec.
Overall execution time: 43.332 sec.
[super@enyo ics432_pa5_adam359]$ ./run_concur smear photos
rrrrrrrrrprwprpwrwprwprwpwrprwprwprwprwprwprwprwprwprwprwprpwrwprwprwprwprwprwprwprwprwprwprpwrwprwpwrprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprpwrwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwprwpwpwpwpwpwpwpwpwpw
Time spent reading: 4.674 sec.
Time spent processing: 29.831 sec.
Time spent writing: 9.734 sec.
Overall execution time: 30.351 sec.

[super@enyo ics432_pa5_adam359]$ ./run_seq invert photos
rpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpwrpw
Time spent reading: 4.353 sec.
Time spent processing: 17.081 sec.
Time spent writing: 8.877 sec.
Overall execution time: 30.446 sec.
[super@enyo ics432_pa5_adam359]$ ./run_concur invert photos
rrrrrrrprrrwprprwwprwprpwwrprwprpwrwprwprwprwprwprwprwprwpprwrwprwprwprwprwprwprwprwprprwwprwprwprpwwrprwprwprwprwprwprwprwprwprwprwprwprwprwprprwwprwprwprpwrwprwprwprwprprwwprwprwprwprpwrwprwprwprwprwprwprwprwprpwrwprwprwpwppwwpwppwwpwpwpw
Time spent reading: 4.718 sec.
Time spent processing: 17.336 sec.
Time spent writing: 9.33 sec.
Overall execution time: 17.889 sec.
---------------------------------------------------------------

                     Sequential Analysis

---------------------------------------------------------------

According to the data above, the most I/O intensive filter is
invert, and the least intensive is oil3. (I sorted from bottom
up)

So in theory, oil filters have the most potential for the 
greatest speedup, as the total execution time for smear and 
invert are strongly bound by the disk I/O.

My above assumption was completely wrong, and the inverse
is true by the implementation of this assignment.

Since there is only one thread doing processing, the 
runtime of the program is bounded by the time it takes to
process the image, and not the disk I/O. So while an image
is being processed, multiple images can be loaded into memory
and written to disk concurrently.  

As you can see from the data above, the speedup is greatest
where applying the filter is the least expensive, allowing
the most concurrency.

As the filter becomes more expensive to apply, the "reading"
queue fills up, the "writing" queue is emptied, and the threads
operate sequentially, bottlenecked at the processing thread.

Filter  Speedup
oil3    391.191/384.028 = 1.01865 = %1.865  faster
oil1    276.562/261.152 = 1.05901 = %5.901  faster
smear   43.332/30.351   = 1.42770 = %42.77  faster
invert  30.446/17.889   = 1.70194 = %70.194 faster

The correlation between performance gain and I/O intensiveness
is positive. The more intense the I/O is, the better the 
program performs.
