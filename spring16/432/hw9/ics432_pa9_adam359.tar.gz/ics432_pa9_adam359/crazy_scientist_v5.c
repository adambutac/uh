#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>
#include <sys/time.h>
#include <pthread.h>

#define SIZE 50

struct work_args {
    pthread_mutex_t *mutex;
    pthread_cond_t *not_full;
    pthread_cond_t *not_empty;
    struct timeval *start;
    struct timeval *end;
    int **matrix;
    int *row;
    int *count;
    int id; 
    int size;
};


double do_crazy_computation(int i,int j);
double standard_deviation(double vals[], int length);
double average(double vals[], int length);
double max_deviation(double vals[], int length);
void *do_work(void *arg);
int work_push(struct work_args *s);
int work_pop(struct work_args *s);

int work_push(struct work_args *s){
    pthread_mutex_lock(s->mutex);
    while(*(s->count) == s->size){
        pthread_cond_wait(s->not_full, s->mutex);
    }
    (*(s->count))++;
    pthread_cond_signal(s->not_empty);
    pthread_mutex_unlock(s->mutex);
}

int work_pop(struct work_args *s){
    pthread_mutex_lock(s->mutex);
    while(*(s->count) == 0){
        pthread_cond_wait(s->not_empty, s->mutex);
    }
    (*(s->count))--;
    pthread_cond_signal(s->not_full);
    pthread_mutex_unlock(s->mutex);
}

int main(int argc, char **argv) {
  int row = 0;
  int numthreads = 2;
  double mat[SIZE][SIZE];
  double check[SIZE][SIZE];
  struct timeval start[numthreads+1], end[numthreads+1];
  double elapsed[numthreads+1];
  int half = SIZE/2;
  gettimeofday(&start[2], NULL);

  //make threads do work
  pthread_mutex_t mutex;
  pthread_cond_t not_full;
  pthread_cond_t not_empty;
  pthread_mutex_init(&mutex, NULL);
  pthread_cond_init(&not_full, NULL);
  pthread_cond_init(&not_empty, NULL);
  struct work_args args[numthreads];
  pthread_t *threads = (pthread_t *)calloc(numthreads, sizeof(pthread_t));

  for(int i = 0; i < numthreads; i++){
    args[i].row = &row; 
    args[i].mutex = &mutex;
    args[i].not_full = &not_full;
    args[i].not_empty = &not_empty;
    args[i].id = i;
    args[i].start = &start[i];
    args[i].end = &end[i];
    args[i].matrix = (int **)&mat;
    if(pthread_create(&threads[i], NULL, do_work, (void*)(&args[i]))){
      fprintf(stderr, "Error creating thread, exiting...");
      exit(1);
    }
  }

  for(int i = 0; i < numthreads; i++){
    pthread_join(threads[i], NULL);
  }

  gettimeofday(&end[2], NULL);
  for(int thread=0; thread < numthreads + 1; thread++){
      elapsed[thread] = ((end[thread].tv_sec*1000000.0 + end[thread].tv_usec) -
            (start[thread].tv_sec*1000000.0 + start[thread].tv_usec)) / 1000000.00;
      if(thread < numthreads)
          printf("\nThread #%d Execution time: %.2f seconds",thread, elapsed[thread]);
  }

  double av = average(elapsed, numthreads);
  double max_dev = max_deviation(elapsed, numthreads);
  double std_dev = standard_deviation(elapsed, numthreads);
  printf("\nOverall execution time: %.2f seconds\n",elapsed[2]);
  printf("Load imbalance: %.2f%\n", (max_dev/av)*100.0);
  //printf("Average: %.2f\n", av);
  //printf("Standard Diviation: %.2f\n", std_dev);
  exit(0);
}

void *do_work(void *arg){
    struct work_args *args = (struct work_args*)arg;
    pthread_mutex_t *mutex = args->mutex;
    struct timeval *start = args->start;
    struct timeval *end = args->end;
    int *matrix = (int *)(args->matrix);
    int *row = args->row; 
    int t = args->id; 
    int i = t;

    gettimeofday(start, NULL);
    while(i < SIZE) { /* loop over the rows */
      for (int j=0;j<SIZE;j++) {  /* loop over the columns */
        (matrix+(i))[j] = do_crazy_computation((i),j);
        fprintf(stderr,".");
      }
      pthread_mutex_lock(mutex);
      i = (*row)++;
      pthread_mutex_unlock(mutex);
    }
    gettimeofday(end, NULL);
}

/* Crazy Computation */
double do_crazy_computation(int x,int y) {
   int iter;
   double value=0.0;

   for (iter = 0; iter < 5*x*x*x+1 + y*y*y+1; iter++) {
     value +=  (cos(x*value) + sin(y*value));
   }
  return value;
}

void generate(int** test){
  for (int i=0;i<SIZE;i++) { /* loop over the rows */
    for (int j=0;j<SIZE;j++) {  /* loop over the columns */
      test[i][j] = do_crazy_computation(i,j);
    }
  } 
}

void check(int** good, int** bad){
  for (int i=0;i<SIZE;i++) { /* loop over the rows */
    for (int j=0;j<SIZE;j++) {  /* loop over the columns */
      if(good[i][j] != bad[i][j])
          fprintf(stderr,"ERROR");
      else
          fprintf(stderr,".");
    }
  }
}

double average(double vals[], int length){
    double sum = 0;
    for(int i = 0; i < length; i++){
        sum += vals[i];
    }
    sum /= length;
    return sum;
}

double standard_deviation(double vals[], int length){
    double av = average(vals, length);
    double sum = 0;
    double value = 0;
    for(int i = 0; i < length; i++){
       value = vals[i] -  av;
       value *= value;
       sum += value;
    }
    sum /= length;
    return sqrt(sum);
}

double max_deviation(double vals[], int length){
    double av = average(vals, length);
    double max = 0;
    double value = 0;
    for(int i = 0; i < length; i++){
       value = fabs(vals[i] -  av);
       if(value > max){
            max = value;
       }
    }
    return max;
}
