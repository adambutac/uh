#include <iostream>
#include <string>
#include <unordered_map>

using namespace std;
int main(){
    cout << "hello world!";
    return 0;
}
