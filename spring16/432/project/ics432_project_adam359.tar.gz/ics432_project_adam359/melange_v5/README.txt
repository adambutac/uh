Tried to use a hashmap in c++ to memoize calculations that were previously done. It killed performance tremendously. Having to access memory outside of the cache is devistating.
