got super lucky and commented out a nested loop. time is now about half a
second. I swear I've done this before too... I dont know why I'm not using
git. I half felt like it would be a hassle for you, but I'm pretty sure you
were just trolling the class that one day asking "Oh, how do I revert my
git??"
