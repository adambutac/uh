Changing all floating point numbers to doubles increased performance slightly,
while changing them all to floating point decreased performance noticeably.
