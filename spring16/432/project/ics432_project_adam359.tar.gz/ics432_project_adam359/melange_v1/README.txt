Instead of starting off with the obvious of trying to parallelize parts of the
code, I decided to start with the not so obvious parts.

The first thing I tried was removing the "background panel" and setting the
anbient color to be white. Although this reduced runtime by about a factor
of 3, it yeilded incorrect results. The image is clearly different from the
original.

