
public class Part1 {
	
	public static void main(String[] args) {
		// Declare and initialize an ArrayList of Strings called sharks.
	
		// Use the add(Object o) method to add the following names to the array:
		// "Bull Shark", "Happy Shark", "Sand Tiger Shark", "Tiger Shark", "Totoro Shark"
	
		// Use the set(int index, Object o) method to change "Happy Shark" to "Great White Shark"
		
		// Use the add(int index, Object o) method to insert "Blacktip Reef Shark" into index 0
			
		// Use the remove(Object o) OR remove(int index) method to remove "Totoro Shark"
			
		// Use a for loop to print out all the shark names in the ArrayList.  
		// You will need to use the size() and get(int index) methods to accomplish this

	}
}

